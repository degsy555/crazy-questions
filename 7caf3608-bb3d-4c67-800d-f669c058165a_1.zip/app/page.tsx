
'use client';

import { useState } from 'react';

interface Question {
  id: number;
  question: string;
  answer: string;
}

interface QuestionData {
  [key: string]: Question[];
}

const questionData: QuestionData = {
  'Food & Drink': [
    {
      id: 1,
      question: "Why do we say 'after dark' when it's actually after light?",
      answer: "Because 'dark' refers to the absence of light, so 'after dark' means after the light has gone away!"
    },
    {
      id: 2,
      question: "If you eat yourself, would you become twice as big or disappear completely?",
      answer: "Physically impossible! But theoretically, you'd probably just get very confused and need medical attention."
    },
    {
      id: 3,
      question: "Why is it called 'rush hour' when nobody's moving?",
      answer: "Because everyone is rushing to get somewhere, they're just all stuck together doing it!"
    },
    {
      id: 4,
      question: "Do fish get thirsty?",
      answer: "No! Fish absorb water through their gills and skin, so they don't need to drink like land animals."
    },
    {
      id: 5,
      question: "Why do we cook bacon and bake cookies?",
      answer: "English is weird! 'Cook' originally meant any form of heating food, while 'bake' specifically meant using dry heat in an oven."
    }
  ],
  'Science': [
    {
      id: 6,
      question: "If the universe is expanding, what is it expanding into?",
      answer: "Space itself is expanding! It's not expanding 'into' anything - it's creating more space as it goes."
    },
    {
      id: 7,
      question: "Why don't we feel the Earth spinning?",
      answer: "We're moving with it! Plus, Earth spins at a constant speed, so there's no acceleration to feel."
    },
    {
      id: 8,
      question: "What came first: the chicken or the egg?",
      answer: "The egg! Other animals were laying eggs millions of years before chickens evolved."
    },
    {
      id: 9,
      question: "If you traveled at the speed of light, would you still need headlights?",
      answer: "You couldn't see anything! At light speed, time would stop for you, and photons couldn't catch up to enter your eyes."
    },
    {
      id: 10,
      question: "Why is the sky blue and not purple?",
      answer: "Blue light scatters more than other colors due to its shorter wavelength, but our eyes are also more sensitive to blue than violet!"
    }
  ],
  'Daily Life': [
    {
      id: 11,
      question: "Why do we say 'slept like a baby' when babies wake up every few hours?",
      answer: "Because when babies do sleep, they sleep very deeply and peacefully - just not for very long!"
    },
    {
      id: 12,
      question: "Why do we press harder on the remote control when we know the batteries are dead?",
      answer: "Hope and desperation! We think maybe there's just enough juice left for one more button press."
    },
    {
      id: 13,
      question: "Why do we say 'heads up' when we actually want people to duck?",
      answer: "It originated from military commands meaning 'pay attention' or 'be alert' - not literally lift your head!"
    },
    {
      id: 14,
      question: "Why do we call it 'getting your hair cut' when you're cutting all of it?",
      answer: "Because 'hair' is treated as a mass noun in English - like 'water' or 'sand' - even though it's made of individual strands."
    },
    {
      id: 15,
      question: "Why do we say 'after it's all said and done' when more is usually said than done?",
      answer: "It's an expression meaning 'when everything is finished' - not a mathematical comparison of talking vs. doing!"
    }
  ],
  'Logic': [
    {
      id: 16,
      question: "If you replace every part of a ship one by one, is it still the same ship?",
      answer: "This is the Ship of Theseus paradox! Philosophers still debate it, but it depends on whether identity comes from materials or continuity."
    },
    {
      id: 17,
      question: "Can you have a list of exceptions that has no exceptions?",
      answer: "This creates a paradox! If it has no exceptions, then it's not really a list of exceptions."
    },
    {
      id: 18,
      question: "If Pinocchio says 'My nose will grow now,' what happens?",
      answer: "Classic paradox! If it grows, he told the truth (but it shouldn't grow). If it doesn't grow, he lied (so it should grow)."
    },
    {
      id: 19,
      question: "Is the answer to this question 'no'?",
      answer: "Another paradox! If you answer 'yes', you're contradicting yourself. If you answer 'no', you're confirming the question."
    },
    {
      id: 20,
      question: "If you try to fail and succeed, which have you done?",
      answer: "You've succeeded at failing, which means you've both succeeded and failed simultaneously. Philosophy is fun!"
    }
  ]
};

export default function CrazyQuestions() {
  const [selectedCategory, setSelectedCategory] = useState('Food & Drink');
  const [currentQuestion, setCurrentQuestion] = useState<Question>(questionData['Food & Drink'][0]);
  const [showAnswer, setShowAnswer] = useState(false);
  const [isAnimating, setIsAnimating] = useState(false);

  const categories = Object.keys(questionData);

  const generateRandomQuestion = (category: string) => {
    const questions = questionData[category];
    const randomIndex = Math.floor(Math.random() * questions.length);
    return questions[randomIndex];
  };

  const handleCategoryChange = (category: string) => {
    if (category === selectedCategory) return;
    
    setIsAnimating(true);
    setTimeout(() => {
      setSelectedCategory(category);
      setCurrentQuestion(generateRandomQuestion(category));
      setShowAnswer(false);
      setIsAnimating(false);
    }, 200);
  };

  const handleGenerateAnother = () => {
    setIsAnimating(true);
    setTimeout(() => {
      setCurrentQuestion(generateRandomQuestion(selectedCategory));
      setShowAnswer(false);
      setIsAnimating(false);
    }, 200);
  };

  const toggleAnswer = () => {
    setShowAnswer(!showAnswer);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-400 via-pink-500 to-red-500 p-4">
      <div className="max-w-lg mx-auto">
        {/* Header */}
        <div className="text-center mb-8 pt-8">
          <h1 className="text-4xl font-bold text-white mb-2" style={{ fontFamily: 'var(--font-pacifico)' }}>
            Crazy Questions
          </h1>
          <p className="text-white/90 text-lg">Mind-bending questions that'll make you think!</p>
        </div>

        {/* Category Tabs */}
        <div className="bg-white/20 backdrop-blur-sm rounded-2xl p-2 mb-6">
          <div className="grid grid-cols-2 gap-2">
            {categories.map((category) => (
              <button
                key={category}
                onClick={() => handleCategoryChange(category)}
                className={`px-4 py-3 rounded-xl font-semibold transition-all duration-300 whitespace-nowrap ${
                  selectedCategory === category
                    ? 'bg-white text-purple-600 shadow-lg transform scale-105'
                    : 'text-white/80 hover:text-white hover:bg-white/10'
                }`}
              >
                {category}
              </button>
            ))}
          </div>
        </div>

        {/* Question Card */}
        <div className={`bg-white rounded-3xl shadow-2xl p-8 mb-6 transition-all duration-300 ${
          isAnimating ? 'opacity-50 transform scale-95' : 'opacity-100 transform scale-100'
        }`}>
          {/* Question */}
          <div className="mb-6">
            <div className="w-12 h-12 bg-gradient-to-r from-purple-500 to-pink-500 rounded-full flex items-center justify-center mb-4">
              <i className="ri-question-line text-white text-xl"></i>
            </div>
            <h2 className="text-2xl font-bold text-gray-800 mb-4 leading-tight">
              {currentQuestion.question}
            </h2>
          </div>

          {/* Answer */}
          <div className={`transition-all duration-500 overflow-hidden ${
            showAnswer ? 'max-h-96 opacity-100' : 'max-h-0 opacity-0'
          }`}>
            <div className="border-t border-gray-200 pt-6">
              <div className="w-12 h-12 bg-gradient-to-r from-green-500 to-blue-500 rounded-full flex items-center justify-center mb-4">
                <i className="ri-lightbulb-line text-white text-xl"></i>
              </div>
              <p className="text-gray-700 text-lg leading-relaxed">
                {currentQuestion.answer}
              </p>
            </div>
          </div>

          {/* Action Buttons */}
          <div className="flex flex-col sm:flex-row gap-4 mt-8">
            <button
              onClick={toggleAnswer}
              className={`flex-1 px-6 py-4 rounded-2xl font-semibold transition-all duration-300 transform hover:scale-105 whitespace-nowrap ${
                showAnswer
                  ? 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                  : 'bg-gradient-to-r from-green-500 to-blue-500 text-white hover:from-green-600 hover:to-blue-600 shadow-lg'
              }`}
            >
              <i className={`ri-${showAnswer ? 'eye-off' : 'eye'}-line mr-2`}></i>
              {showAnswer ? 'Hide Answer' : 'Reveal Answer'}
            </button>
            
            <button
              onClick={handleGenerateAnother}
              className="flex-1 px-6 py-4 bg-gradient-to-r from-purple-500 to-pink-500 text-white rounded-2xl font-semibold hover:from-purple-600 hover:to-pink-600 transition-all duration-300 transform hover:scale-105 shadow-lg whitespace-nowrap"
            >
              <i className="ri-refresh-line mr-2"></i>
              Generate Another
            </button>
          </div>
        </div>

        {/* Category Info */}
        <div className="text-center">
          <div className="bg-white/20 backdrop-blur-sm rounded-2xl p-4">
            <p className="text-white/90 text-sm">
              Category: <span className="font-semibold">{selectedCategory}</span>
            </p>
            <p className="text-white/70 text-xs mt-1">
              {questionData[selectedCategory].length} questions available
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}
